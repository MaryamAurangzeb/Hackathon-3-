
export const validateInput = (input) => !!input.trim();
