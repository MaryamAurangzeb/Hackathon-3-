
import React from 'react';
const ProductDetail = () => <div>Product Detail</div>;
export default ProductDetail;
