
export const fetchProducts = async () => {
    return [{ id: 1, name: 'Sample Product' }];
};
