
import React, { useState } from 'react';
const CheckoutFlow = () => {
    const [step, setStep] = useState(1);
    return <div>Checkout Step: {step}</div>;
};
export default CheckoutFlow;
