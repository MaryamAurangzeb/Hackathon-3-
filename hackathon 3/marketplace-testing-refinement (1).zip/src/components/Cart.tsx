
import React from 'react';
const Cart = () => <div>Your Cart</div>;
export default Cart;
