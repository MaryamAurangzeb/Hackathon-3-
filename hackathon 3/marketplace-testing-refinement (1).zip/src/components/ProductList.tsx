
import React from 'react';
const ProductList = () => <div>Product List</div>;
export default ProductList;
