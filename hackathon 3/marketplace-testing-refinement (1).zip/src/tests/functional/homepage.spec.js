
describe('Homepage Tests', () => {
    it('should load the homepage', () => {
        cy.visit('/');
        cy.contains('Product List');
    });
});
